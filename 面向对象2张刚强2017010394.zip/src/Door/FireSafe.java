package Door;

/**
 * Created by 13120 on 2020/4/15.
 */
public interface FireSafe {
    abstract void fireProof();

}
